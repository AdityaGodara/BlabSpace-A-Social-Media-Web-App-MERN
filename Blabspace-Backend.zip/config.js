const PORT = 5555;
const mongodbURL = "mongodb+srv://adityagodara03:MainCluster_ggland1357@maincluster.pnnbb0n.mongodb.net/?retryWrites=true&w=majority&appName=MainCluster"
const secretKey = "QOICNQ@3H3$#"
module.exports ={ PORT,mongodbURL,secretKey }